package com.aidesktopagent.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class AppConfigTest {

    @Test
    void loadReturnsNonNullConfig() {
        AppConfig config = AppConfig.load();
        assertNotNull(config.getAppName());
        assertNotNull(config.getAppVersion());
        assertNotNull(config.getLogLevel());
    }

    @Test
    void defaultValuesAreSensible() {
        AppConfig config = AppConfig.load("nonexistent.properties");
        assertEquals("AI Desktop Agent", config.getAppName());
        assertEquals("0.1.0-SNAPSHOT", config.getAppVersion());
        assertEquals("INFO", config.getLogLevel());
    }
}
