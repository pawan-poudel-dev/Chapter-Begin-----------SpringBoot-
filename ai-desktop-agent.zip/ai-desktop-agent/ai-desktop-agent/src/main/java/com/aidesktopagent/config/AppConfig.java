package com.aidesktopagent.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

/**
 * Application configuration loaded from classpath resources.
 * Extensible for future settings (AI providers, voice, paths, etc.).
 */
public final class AppConfig {

    private static final Logger log = LoggerFactory.getLogger(AppConfig.class);
    private static final String DEFAULT_RESOURCE = "application.properties";

    private final String appName;
    private final String appVersion;
    private final String logLevel;

    private AppConfig(String appName, String appVersion, String logLevel) {
        this.appName = Objects.requireNonNull(appName, "appName");
        this.appVersion = Objects.requireNonNull(appVersion, "appVersion");
        this.logLevel = Objects.requireNonNull(logLevel, "logLevel");
    }

    public static AppConfig load() {
        return load(DEFAULT_RESOURCE);
    }

    public static AppConfig load(String resourceName) {
        Properties props = new Properties();
        try (InputStream in = AppConfig.class.getClassLoader().getResourceAsStream(resourceName)) {
            if (in == null) {
                log.warn("Configuration resource '{}' not found; using defaults", resourceName);
            } else {
                props.load(in);
                log.debug("Loaded configuration from {}", resourceName);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to load configuration: " + resourceName, e);
        }

        String appName = props.getProperty("app.name", "AI Desktop Agent");
        String appVersion = props.getProperty("app.version", "0.1.0-SNAPSHOT");
        String logLevel = props.getProperty("logging.level", "INFO");

        return new AppConfig(appName, appVersion, logLevel);
    }

    public String getAppName() {
        return appName;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public String getLogLevel() {
        return logLevel;
    }
}
