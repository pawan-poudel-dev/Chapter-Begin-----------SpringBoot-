/**
 * Security, permissions, and sandboxing (not implemented yet).
 */
package com.aidesktopagent.security;
