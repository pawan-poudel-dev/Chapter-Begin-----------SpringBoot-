/**
 * Desktop UI components (not implemented yet).
 */
package com.aidesktopagent.ui;
