package com.aidesktopagent;

import com.aidesktopagent.config.AppConfig;
import com.aidesktopagent.logging.LoggingBootstrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry point for the AI Desktop Agent.
 * Initializes configuration and logging, then starts and shuts down cleanly.
 * AI and computer-control features are intentionally not implemented yet.
 */
public final class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    private Main() {
        // utility class
    }

    public static void main(String[] args) {
        // Bootstrap logging first so subsequent messages are captured.
        LoggingBootstrap.init();

        log.info("Initializing AI Desktop Agent...");

        try {
            AppConfig config = AppConfig.load();
            log.info("Configuration loaded (app.name={}, app.version={})",
                    config.getAppName(), config.getAppVersion());

            // Placeholder for future subsystem initialization
            // (agent, ai, voice, actions, computer, files, browser, music,
            //  security, verification, recovery, avatar, ui)

            System.out.println("AI Desktop Agent started successfully.");
            log.info("AI Desktop Agent started successfully.");

            // Clean shutdown path for foundation stage.
            shutdown();
        } catch (Exception e) {
            log.error("Failed to start AI Desktop Agent", e);
            System.err.println("AI Desktop Agent failed to start: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void shutdown() {
        log.info("Shutting down AI Desktop Agent...");
        // Future: release resources, stop services, etc.
        log.info("AI Desktop Agent shut down cleanly.");
    }
}
