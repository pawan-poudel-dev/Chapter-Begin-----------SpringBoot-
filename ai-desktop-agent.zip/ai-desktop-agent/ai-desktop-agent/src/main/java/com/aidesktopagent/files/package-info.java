/**
 * File system operations (not implemented yet).
 */
package com.aidesktopagent.files;
