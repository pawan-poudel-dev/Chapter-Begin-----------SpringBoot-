/**
 * Avatar / visual representation (not implemented yet).
 */
package com.aidesktopagent.avatar;
