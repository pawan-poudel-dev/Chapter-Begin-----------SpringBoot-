/**
 * Speech recognition and text-to-speech (not implemented yet).
 */
package com.aidesktopagent.voice;
