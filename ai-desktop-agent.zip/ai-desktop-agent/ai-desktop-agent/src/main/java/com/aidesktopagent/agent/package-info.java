/**
 * Core agent orchestration and lifecycle management.
 * Intentionally empty for Day 1 foundation.
 */
package com.aidesktopagent.agent;
