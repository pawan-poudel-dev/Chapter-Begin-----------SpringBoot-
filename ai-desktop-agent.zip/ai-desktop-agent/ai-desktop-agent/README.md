# AI Desktop Agent

Foundation project for a modern Java desktop AI agent.

**Status:** Week 1 / Day 1 — Project Creation  
Java 17 LTS · Maven · Clean package structure

## Requirements

- Java 17 (LTS) or newer
- Maven 3.9+

## Quick Start

```bash
# Build
mvn clean package

# Run
java -jar target/ai-desktop-agent-0.1.0-SNAPSHOT.jar
```

Expected console output:

```
AI Desktop Agent started successfully.
```

## Project Structure

```
ai-desktop-agent/
├── pom.xml
├── README.md
├── .gitignore
├── src/
│   ├── main/
│   │   ├── java/com/aidesktopagent/
│   │   │   ├── Main.java              # Entry point
│   │   │   ├── agent/                 # Core agent orchestration
│   │   │   ├── ai/                    # AI model integration
│   │   │   ├── voice/                 # Speech I/O
│   │   │   ├── actions/               # High-level actions
│   │   │   ├── computer/              # Computer control
│   │   │   ├── files/                 # File system
│   │   │   ├── browser/               # Browser automation
│   │   │   ├── music/                 # Media control
│   │   │   ├── security/              # Security & permissions
│   │   │   ├── verification/          # Safety checks
│   │   │   ├── recovery/              # Error recovery
│   │   │   ├── avatar/                # Visual avatar
│   │   │   ├── ui/                    # Desktop UI
│   │   │   ├── config/                # Configuration
│   │   │   └── logging/               # Logging bootstrap
│   │   └── resources/
│   │       ├── application.properties
│   │       └── logback.xml
│   └── test/
│       └── java/com/aidesktopagent/
│           ├── MainTest.java
│           └── config/AppConfigTest.java
```

## Design Notes (Day 1)

- **No AI or computer-control implementation** — packages are placeholders only.
- Application starts, loads configuration, initializes logging, prints the success message, and shuts down cleanly.
- Logging via SLF4J + Logback (console + rolling file under `logs/`).
- Configuration via `application.properties` (extensible).
- Tests with JUnit 5.

## Building & Testing

```bash
mvn clean test
mvn clean package
```

## License

Proprietary — internal foundation project.
