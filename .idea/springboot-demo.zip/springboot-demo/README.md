# Spring Boot Product CRUD API (Beginner Example)

A minimal REST API demonstrating standard Spring Boot layering:

```
Controller  ->  Service  ->  Repository  ->  Database (H2, in-memory)
   |               |              |
 HTTP/JSON    business logic   data access
```

## Prerequisites
- Java 17+
- Maven (or just use the included setup — no separate DB install needed)

## How to run

```bash
mvn spring-boot:run
```

The app starts on **http://localhost:8080**

## Endpoints

| Method | URL                     | Description          |
|--------|-------------------------|-----------------------|
| GET    | /api/products           | List all products    |
| GET    | /api/products/{id}      | Get one product      |
| POST   | /api/products           | Create a product     |
| PUT    | /api/products/{id}      | Update a product     |
| DELETE | /api/products/{id}      | Delete a product     |

### Example: create a product

```bash
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{"name": "Keyboard", "price": 49.99, "quantity": 10}'
```

### Example: get all products

```bash
curl http://localhost:8080/api/products
```

## Peeking at the database

Since this uses an in-memory H2 database, data resets every restart —
that's intentional for learning/testing. You can view the tables in a
browser at:

http://localhost:8080/h2-console

Use JDBC URL: `jdbc:h2:mem:productdb`, username `sa`, empty password.

## Project structure

```
src/main/java/com/example/demo/
 ├── DemoApplication.java        # entry point (main method)
 ├── model/Product.java          # the database entity (table)
 ├── repository/ProductRepository.java  # data access (auto-generated queries)
 ├── service/ProductService.java # business logic
 ├── controller/ProductController.java  # HTTP endpoints
 └── exception/                  # custom errors + a global handler
```

## Next steps to learn from here
- Swap H2 for MySQL/Postgres (just change `application.properties` + add the driver dependency)
- Add pagination to `GET /api/products` (`Pageable` parameter)
- Add unit tests for `ProductService` using Mockito
- Add authentication with Spring Security
