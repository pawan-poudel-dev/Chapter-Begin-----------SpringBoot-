package com.example.demo.repository;

import com.example.demo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * This is the "database layer". You don't write any SQL here.
 * By extending JpaRepository<Product, Long>, Spring automatically
 * generates implementations for save(), findById(), findAll(),
 * deleteById(), etc. at runtime.
 *
 * If you need a custom query, you can just declare a method like:
 *   List<Product> findByNameContainingIgnoreCase(String name);
 * and Spring Data JPA will generate the SQL for you based on the method name.
 */
public interface ProductRepository extends JpaRepository<Product, Long> {
}
