package com.example.demo.exception;

/**
 * A custom, meaningful exception instead of throwing a generic RuntimeException.
 * We'll catch this in a global handler and turn it into a clean 404 response.
 */
public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(Long id) {
        super("Product not found with id: " + id);
    }
}
