package com.example.demo.service;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * The "business logic" layer. Controllers should stay thin and just
 * handle HTTP concerns; the actual decision-making/rules live here.
 * This also makes the logic easy to unit test without needing a web server.
 */
@Service
public class ProductService {

    private final ProductRepository productRepository;

    // Constructor injection (preferred over @Autowired on fields) —
    // Spring automatically supplies a ProductRepository bean here.
    @Autowired
    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));
    }

    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    public Product updateProduct(Long id, Product updatedProduct) {
        Product existing = getProductById(id); // reuses the not-found check above
        existing.setName(updatedProduct.getName());
        existing.setPrice(updatedProduct.getPrice());
        existing.setQuantity(updatedProduct.getQuantity());
        return productRepository.save(existing);
    }

    public void deleteProduct(Long id) {
        Product existing = getProductById(id); // throws 404 if it doesn't exist
        productRepository.delete(existing);
    }
}
