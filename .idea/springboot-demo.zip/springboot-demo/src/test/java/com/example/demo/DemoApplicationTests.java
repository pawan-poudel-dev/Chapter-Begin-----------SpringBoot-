package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * A minimal "smoke test": if the Spring application context
 * fails to start (bad config, missing bean, etc.), this test fails.
 */
@SpringBootTest
class DemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
